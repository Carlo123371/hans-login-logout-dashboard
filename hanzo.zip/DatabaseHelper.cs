﻿
using System;
using System.Data;
using System.Data.OleDb;
using System.IO;

namespace hanslogin
{
    public static class DatabaseHelper
    {
        private static readonly string DatabasePath =
            Path.GetFullPath(
                Path.Combine(
                    AppContext.BaseDirectory,
                    "..",
                    "..",
                    "..",
                    "HansLogin.accdb"
                )
            );

        private static readonly string ConnectionString =
            $"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={DatabasePath};Persist Security Info=False;";

        // CREATE AND UPDATE PRODUCTS TABLE
        public static void EnsureProductsTable()
        {
            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();

                DataTable tables = connection.GetSchema(
                    "Tables",
                    new string?[] { null, null, "Products", "TABLE" });

                if (tables.Rows.Count == 0)
                {
                    string createSql =
                        "CREATE TABLE Products (" +
                        "ProductID COUNTER CONSTRAINT PK_Products PRIMARY KEY, " +
                        "ProductName TEXT(100) NOT NULL, " +
                        "Category TEXT(50), " +
                        "Quantity LONG, " +
                        "ReorderLevel LONG, " +
                        "Price CURRENCY, " +
                        "[Description] MEMO)";

                    using OleDbCommand command =
                        new OleDbCommand(createSql, connection);

                    command.ExecuteNonQuery();
                }
                else
                {
                    // CHECK IF REORDER LEVEL COLUMN EXISTS
                    DataTable columns = connection.GetSchema(
                        "Columns",
                        new string?[] { null, null, "Products", null });

                    bool hasReorderLevel = false;

                    foreach (DataRow row in columns.Rows)
                    {
                        string columnName =
                            Convert.ToString(row["COLUMN_NAME"]) ?? "";

                        if (columnName.Equals(
                            "ReorderLevel",
                            StringComparison.OrdinalIgnoreCase))
                        {
                            hasReorderLevel = true;
                            break;
                        }
                    }

                    // ADD MISSING COLUMN WITHOUT DELETING DATA
                    if (!hasReorderLevel)
                    {
                        using OleDbCommand alterCommand =
                            new OleDbCommand(
                                "ALTER TABLE Products ADD COLUMN ReorderLevel LONG",
                                connection);

                        alterCommand.ExecuteNonQuery();
                    }

                    // SET DEFAULT REORDER LEVEL FOR OLD PRODUCTS
                    using OleDbCommand updateCommand =
                        new OleDbCommand(
                            "UPDATE Products SET ReorderLevel = 5 WHERE ReorderLevel IS NULL",
                            connection);

                    updateCommand.ExecuteNonQuery();
                }
            }
        }

        // GET PRODUCTS
        public static DataTable GetProducts(string searchText = "")
        {
            EnsureProductsTable();

            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();

                string sql =
                    "SELECT ProductID, ProductName, Category, Quantity, " +
                    "ReorderLevel, Price, [Description] FROM Products ";

                using OleDbCommand command = new OleDbCommand();
                command.Connection = connection;

                if (!string.IsNullOrWhiteSpace(searchText))
                {
                    sql += "WHERE ProductName LIKE ? OR Category LIKE ? ";

                    command.Parameters.Add("?", OleDbType.VarWChar, 100)
                        .Value = "*" + searchText.Trim() + "*";

                    command.Parameters.Add("?", OleDbType.VarWChar, 50)
                        .Value = "*" + searchText.Trim() + "*";
                }

                sql += "ORDER BY ProductID DESC";
                command.CommandText = sql;

                DataTable result = new DataTable();

                using OleDbDataAdapter adapter =
                    new OleDbDataAdapter(command);

                adapter.Fill(result);

                return result;
            }
        }

        // ADD PRODUCT
        public static bool AddProduct(
            string productName,
            string category,
            int quantity,
            int reorderLevel,
            decimal price,
            string description)
        {
            EnsureProductsTable();

            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();

                string sql =
                    "INSERT INTO Products " +
                    "(ProductName, Category, Quantity, ReorderLevel, Price, [Description]) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";

                using OleDbCommand command =
                    new OleDbCommand(sql, connection);

                command.Parameters.Add("?", OleDbType.VarWChar, 100)
                    .Value = productName.Trim();

                command.Parameters.Add("?", OleDbType.VarWChar, 50)
                    .Value = string.IsNullOrWhiteSpace(category)
                        ? DBNull.Value : category.Trim();

                command.Parameters.Add("?", OleDbType.Integer)
                    .Value = quantity;

                command.Parameters.Add("?", OleDbType.Integer)
                    .Value = reorderLevel;

                command.Parameters.Add("?", OleDbType.Currency)
                    .Value = price;

                command.Parameters.Add("?", OleDbType.LongVarWChar)
                    .Value = string.IsNullOrWhiteSpace(description)
                        ? DBNull.Value : description.Trim();

                return command.ExecuteNonQuery() == 1;
            }
        }

        // UPDATE PRODUCT
        public static bool UpdateProduct(
            int productId,
            string productName,
            string category,
            int quantity,
            int reorderLevel,
            decimal price,
            string description)
        {
            EnsureProductsTable();

            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();

                string sql =
                    "UPDATE Products SET " +
                    "ProductName = ?, Category = ?, Quantity = ?, " +
                    "ReorderLevel = ?, Price = ?, [Description] = ? " +
                    "WHERE ProductID = ?";

                using OleDbCommand command =
                    new OleDbCommand(sql, connection);

                command.Parameters.Add("?", OleDbType.VarWChar, 100)
                    .Value = productName.Trim();

                command.Parameters.Add("?", OleDbType.VarWChar, 50)
                    .Value = string.IsNullOrWhiteSpace(category)
                        ? DBNull.Value : category.Trim();

                command.Parameters.Add("?", OleDbType.Integer)
                    .Value = quantity;

                command.Parameters.Add("?", OleDbType.Integer)
                    .Value = reorderLevel;

                command.Parameters.Add("?", OleDbType.Currency)
                    .Value = price;

                command.Parameters.Add("?", OleDbType.LongVarWChar)
                    .Value = string.IsNullOrWhiteSpace(description)
                        ? DBNull.Value : description.Trim();

                command.Parameters.Add("?", OleDbType.Integer)
                    .Value = productId;

                return command.ExecuteNonQuery() == 1;
            }
        }

        // DELETE PRODUCT
        public static bool DeleteProduct(int productId)
        {
            EnsureProductsTable();

            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();

                using OleDbCommand command =
                    new OleDbCommand(
                        "DELETE FROM Products WHERE ProductID = ?",
                        connection);

                command.Parameters.Add("?", OleDbType.Integer)
                    .Value = productId;

                return command.ExecuteNonQuery() == 1;
            }
        }

        // DATABASE LOCATION
        public static string GetDatabasePath()
        {
            return DatabasePath;
        }

        // GET CONNECTION
        public static OleDbConnection GetConnection()
        {
            if (!File.Exists(DatabasePath))
            {
                throw new FileNotFoundException(
                    "Database file not found:\n" + DatabasePath);
            }

            return new OleDbConnection(ConnectionString);
        }

        // TEST CONNECTION
        public static bool TestConnection()
        {
            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();
                return connection.State == ConnectionState.Open;
            }
        }

        // CHECK EXISTING USERNAME
        public static bool UsernameExists(string username)
        {
            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();

                string query =
                    "SELECT COUNT(*) FROM AppUsers WHERE Username = ?";

                using OleDbCommand command =
                    new OleDbCommand(query, connection);

                command.Parameters.Add("?", OleDbType.VarWChar, 50)
                    .Value = username.Trim();

                return Convert.ToInt32(command.ExecuteScalar()) > 0;
            }
        }

        // REGISTER USER
        public static bool RegisterUser(
            string fullName,
            string username,
            string password)
        {
            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();

                string query =
                    "INSERT INTO AppUsers " +
                    "(FullName, Username, PasswordHash) VALUES (?, ?, ?)";

                using OleDbCommand command =
                    new OleDbCommand(query, connection);

                command.Parameters.Add("?", OleDbType.VarWChar, 100)
                    .Value = fullName.Trim();

                command.Parameters.Add("?", OleDbType.VarWChar, 50)
                    .Value = username.Trim();

                command.Parameters.Add("?", OleDbType.LongVarWChar)
                    .Value = PasswordHasher.HashPassword(password);

                return command.ExecuteNonQuery() == 1;
            }
        }

        // FIND USER FOR LOGIN
        public static (string FullName, string PasswordHash)?
            FindUser(string username)
        {
            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();

                string query =
                    "SELECT FullName, PasswordHash " +
                    "FROM AppUsers WHERE Username = ?";

                using OleDbCommand command =
                    new OleDbCommand(query, connection);

                command.Parameters.Add("?", OleDbType.VarWChar, 50)
                    .Value = username.Trim();

                using OleDbDataReader reader = command.ExecuteReader();

                if (reader != null && reader.Read())
                {
                    return (
                        reader["FullName"].ToString() ?? "",
                        reader["PasswordHash"].ToString() ?? ""
                    );
                }
            }

            return null;
        }
    }
}
