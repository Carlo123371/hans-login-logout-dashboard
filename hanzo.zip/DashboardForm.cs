﻿
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace hanslogin
{
    public partial class DashboardForm : Form
    {
        private readonly string _fullName;

        private readonly Color _background = Color.FromArgb(255, 240, 245);
        private readonly Color _pink = Color.DeepPink;
        private readonly Color _darkPink = Color.FromArgb(130, 40, 80);
        private readonly Color _lightPink = Color.FromArgb(255, 220, 232);

        private TextBox txtProductName = new();
        private TextBox txtCategory = new();
        private TextBox txtDescription = new();
        private TextBox txtSearch = new();

        private NumericUpDown numQuantity = new();
        private NumericUpDown numPrice = new();
        private NumericUpDown numReorderLevel = new();

        private DataGridView dgvProducts = new();
        private Label lblSelectedId = new();

        private Label lblTotal = new();
        private Label lblInStock = new();
        private Label lblLowStock = new();
        private Label lblOutStock = new();

        public DashboardForm(string fullName)
        {
            InitializeComponent();
            Controls.Clear();

            _fullName = fullName ?? "";

            Text = "HansLogin - Product Dashboard";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1200, 760);
            MinimumSize = new Size(1000, 700);
            BackColor = _background;
            Font = new Font("Segoe UI", 9);

            BuildDashboard();

            Load -= DashboardForm_Load;
            Load += DashboardForm_Load;
        }

        private void BuildDashboard()
        {
            // HEADER
            Panel header = new Panel
            {
                Dock = DockStyle.Top,
                Height = 75,
                BackColor = _pink
            };

            Label title = new Label
            {
                Text = "HANSLOGIN",
                Font = new Font("Segoe UI", 21, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(25, 8),
                Size = new Size(300, 35)
            };

            Label subtitle = new Label
            {
                Text = "PRODUCT MANAGEMENT DASHBOARD",
                Font = new Font("Segoe UI", 9, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(29, 43),
                Size = new Size(330, 22)
            };

            Label welcome = new Label
            {
                Text = "Welcome, " + _fullName + "!",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                ForeColor = Color.White,
                TextAlign = ContentAlignment.MiddleRight,
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
                Location = new Point(760, 20),
                Size = new Size(270, 35)
            };

            Button btnLogout = MakeButton("LOG OUT", 1040, 17, 120, 40);
            btnLogout.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnLogout.BackColor = Color.White;
            btnLogout.ForeColor = _pink;
            btnLogout.Click += (s, e) => Close();

            header.Controls.Add(title);
            header.Controls.Add(subtitle);
            header.Controls.Add(welcome);
            header.Controls.Add(btnLogout);

            Controls.Add(header);

            // SUMMARY CARDS
            int cardWidth = (ClientSize.Width - 100) / 4;
            int cardY = 95;
            int cardHeight = 105;
            int gap = 15;

            Panel cardTotal = CreateSummaryCard(
                "TOTAL PRODUCTS", Color.FromArgb(255, 210, 225),
                25, cardY, cardWidth, cardHeight, out lblTotal);

            Panel cardInStock = CreateSummaryCard(
                "IN STOCK", Color.FromArgb(255, 190, 215),
                25 + cardWidth + gap, cardY,
                cardWidth, cardHeight, out lblInStock);

            Panel cardLowStock = CreateSummaryCard(
                "LOW STOCK", Color.FromArgb(255, 225, 190),
                25 + (cardWidth + gap) * 2, cardY,
                cardWidth, cardHeight, out lblLowStock);

            Panel cardOutStock = CreateSummaryCard(
                "OUT OF STOCK", Color.FromArgb(255, 195, 205),
                25 + (cardWidth + gap) * 3, cardY,
                cardWidth, cardHeight, out lblOutStock);

            Controls.Add(cardTotal);
            Controls.Add(cardInStock);
            Controls.Add(cardLowStock);
            Controls.Add(cardOutStock);

            // PRODUCT INFORMATION PANEL
            Panel editor = new Panel
            {
                Location = new Point(25, 215),
                Size = new Size(1135, 205),
                Anchor = AnchorStyles.Top |
                         AnchorStyles.Left |
                         AnchorStyles.Right,
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };

            Controls.Add(editor);

            Label editorTitle = new Label
            {
                Text = "PRODUCT INFORMATION",
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                ForeColor = _darkPink,
                Location = new Point(15, 10),
                Size = new Size(300, 25)
            };

            editor.Controls.Add(editorTitle);

            lblSelectedId = new Label
            {
                Text = "Selected Product ID: New",
                Location = new Point(790, 12),
                Size = new Size(320, 22),
                ForeColor = Color.Gray,
                TextAlign = ContentAlignment.MiddleRight,
                Anchor = AnchorStyles.Top | AnchorStyles.Right
            };

            editor.Controls.Add(lblSelectedId);

            // PRODUCT NAME
            AddEditorLabel(editor, "Product Name", 43, 20);
            txtProductName = AddEditorTextBox(editor, 65, 20, 255);

            // CATEGORY
            AddEditorLabel(editor, "Category", 43, 300);
            txtCategory = AddEditorTextBox(editor, 65, 300, 255);

            // UNIT PRICE
            AddEditorLabel(editor, "Unit Price", 43, 580);

            numPrice = new NumericUpDown
            {
                Location = new Point(580, 65),
                Size = new Size(240, 30),
                Minimum = 0,
                Maximum = 100000000,
                DecimalPlaces = 2,
                ThousandsSeparator = true,
                Font = new Font("Segoe UI", 9)
            };

            editor.Controls.Add(numPrice);

            // DESCRIPTION
            AddEditorLabel(editor, "Description", 108, 20);

            txtDescription = new TextBox
            {
                Location = new Point(20, 130),
                Size = new Size(255, 52),
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                Font = new Font("Segoe UI", 9)
            };

            editor.Controls.Add(txtDescription);

            // QUANTITY
            AddEditorLabel(editor, "Quantity", 108, 300);

            numQuantity = new NumericUpDown
            {
                Location = new Point(300, 130),
                Size = new Size(255, 30),
                Minimum = 0,
                Maximum = 1000000,
                ThousandsSeparator = true,
                Font = new Font("Segoe UI", 9)
            };

            editor.Controls.Add(numQuantity);

            // REORDER LEVEL
            AddEditorLabel(editor, "Reorder Level", 108, 580);

            numReorderLevel = new NumericUpDown
            {
                Location = new Point(580, 130),
                Size = new Size(240, 30),
                Minimum = 0,
                Maximum = 1000000,
                Value = 5,
                ThousandsSeparator = true,
                Font = new Font("Segoe UI", 9)
            };

            editor.Controls.Add(numReorderLevel);

            // ACTION BUTTONS
            Button btnAdd = MakeButton("ADD PRODUCT", 850, 45, 125, 34);
            btnAdd.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnAdd.Click += AddProduct_Click;

            Button btnUpdate = MakeButton("UPDATE", 850, 84, 125, 34);
            btnUpdate.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnUpdate.BackColor = Color.FromArgb(80, 150, 220);
            btnUpdate.Click += UpdateProduct_Click;

            Button btnDelete = MakeButton("DELETE", 985, 45, 125, 34);
            btnDelete.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnDelete.BackColor = Color.FromArgb(190, 55, 95);
            btnDelete.Click += DeleteProduct_Click;

            Button btnClear = MakeButton("CLEAR", 985, 84, 125, 34);
            btnClear.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnClear.BackColor = Color.FromArgb(150, 120, 135);
            btnClear.Click += (s, e) => ClearFields();

            editor.Controls.Add(btnAdd);
            editor.Controls.Add(btnUpdate);
            editor.Controls.Add(btnDelete);
            editor.Controls.Add(btnClear);

            // PRODUCT LIST PANEL
            Panel listPanel = new Panel
            {
                Location = new Point(25, 435),
                Size = new Size(1135, 275),
                Anchor = AnchorStyles.Top |
                         AnchorStyles.Bottom |
                         AnchorStyles.Left |
                         AnchorStyles.Right,
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };

            Controls.Add(listPanel);

            Label listTitle = new Label
            {
                Text = "PRODUCT LIST",
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                ForeColor = _darkPink,
                Location = new Point(15, 10),
                Size = new Size(150, 28)
            };

            listPanel.Controls.Add(listTitle);

            Button btnRefresh = MakeButton("REFRESH", 155, 9, 90, 30);
            btnRefresh.Click += (s, e) => LoadProducts();

            listPanel.Controls.Add(btnRefresh);

            Label searchLabel = new Label
            {
                Text = "Search:",
                Location = new Point(790, 12),
                Size = new Size(60, 25),
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
                ForeColor = _darkPink
            };

            listPanel.Controls.Add(searchLabel);

            txtSearch = new TextBox
            {
                Location = new Point(850, 9),
                Size = new Size(265, 30),
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
                Font = new Font("Segoe UI", 9),
                PlaceholderText = "Search product..."
            };

            txtSearch.TextChanged += (s, e) => LoadProducts();

            listPanel.Controls.Add(txtSearch);

            // PRODUCT GRID
            dgvProducts = new DataGridView
            {
                Location = new Point(15, 48),
                Size = new Size(1100, 210),
                Anchor = AnchorStyles.Top |
                         AnchorStyles.Bottom |
                         AnchorStyles.Left |
                         AnchorStyles.Right,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                MultiSelect = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                RowHeadersVisible = false,
                EnableHeadersVisualStyles = false,
                Font = new Font("Segoe UI", 9),
                GridColor = _lightPink
            };

            dgvProducts.ColumnHeadersDefaultCellStyle.BackColor = _pink;
            dgvProducts.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvProducts.ColumnHeadersDefaultCellStyle.Font =
                new Font("Segoe UI", 9, FontStyle.Bold);

            dgvProducts.DefaultCellStyle.SelectionBackColor = _lightPink;
            dgvProducts.DefaultCellStyle.SelectionForeColor = _darkPink;
            dgvProducts.RowTemplate.Height = 30;

            dgvProducts.SelectionChanged += DgvProducts_SelectionChanged;

            listPanel.Controls.Add(dgvProducts);
        }

        // SUMMARY CARD
        private Panel CreateSummaryCard(
            string title,
            Color cardColor,
            int x,
            int y,
            int width,
            int height,
            out Label valueLabel)
        {
            Panel card = new Panel
            {
                Location = new Point(x, y),
                Size = new Size(width, height),
                BackColor = cardColor,
                BorderStyle = BorderStyle.FixedSingle
            };

            Label cardTitle = new Label
            {
                Text = title,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                ForeColor = _darkPink,
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(5, 12),
                Size = new Size(width - 10, 25)
            };

            valueLabel = new Label
            {
                Text = "0",
                Font = new Font("Segoe UI", 21, FontStyle.Bold),
                ForeColor = _darkPink,
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(5, 42),
                Size = new Size(width - 10, 45)
            };

            card.Controls.Add(cardTitle);
            card.Controls.Add(valueLabel);

            return card;
        }

        private void AddEditorLabel(
            Control parent, string text, int y, int x)
        {
            parent.Controls.Add(new Label
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(250, 20),
                ForeColor = _darkPink,
                Font = new Font("Segoe UI", 9, FontStyle.Bold)
            });
        }

        private TextBox AddEditorTextBox(
            Control parent, int y, int x, int width)
        {
            TextBox textBox = new TextBox
            {
                Location = new Point(x, y),
                Size = new Size(width, 30),
                Font = new Font("Segoe UI", 9)
            };

            parent.Controls.Add(textBox);
            return textBox;
        }

        private Button MakeButton(
            string text, int x, int y, int width, int height)
        {
            return new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(width, height),
                BackColor = _pink,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 8, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
        }

        // DATABASE LOAD
        private void DashboardForm_Load(object? sender, EventArgs e)
        {
            try
            {
                DatabaseHelper.EnsureProductsTable();
                LoadProducts();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Unable to load the product database.\n\n" + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // LOAD PRODUCTS
        private void LoadProducts()
        {
            try
            {
                string search = txtSearch.Text.Trim();

                DataTable products = DatabaseHelper.GetProducts(search);
                dgvProducts.DataSource = products;

                SetColumnHeader("ProductID", "ID");
                SetColumnHeader("ProductName", "Product Name");
                SetColumnHeader("Category", "Category");
                SetColumnHeader("Quantity", "Quantity");
                SetColumnHeader("ReorderLevel", "Reorder Level");
                SetColumnHeader("Price", "Unit Price");
                SetColumnHeader("Description", "Description");

                if (dgvProducts.Columns["Price"] is DataGridViewColumn priceColumn)
                    priceColumn.DefaultCellStyle.Format = "N2";

                UpdateSummary(products);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Could not retrieve products.\n\n" + ex.Message,
                    "Product Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void SetColumnHeader(string columnName, string headerText)
        {
            if (dgvProducts.Columns[columnName] is DataGridViewColumn column)
                column.HeaderText = headerText;
        }

        // UPDATE SUMMARY CARDS
        private void UpdateSummary(DataTable products)
        {
            int total = products.Rows.Count;
            int inStock = 0;
            int lowStock = 0;
            int outStock = 0;

            foreach (DataRow row in products.Rows)
            {
                int quantity = row["Quantity"] == DBNull.Value
                    ? 0
                    : Convert.ToInt32(row["Quantity"]);

                int reorderLevel = row["ReorderLevel"] == DBNull.Value
                    ? 5
                    : Convert.ToInt32(row["ReorderLevel"]);

                if (quantity == 0)
                    outStock++;
                else if (quantity <= reorderLevel)
                    lowStock++;
                else
                    inStock++;
            }

            lblTotal.Text = total.ToString();
            lblInStock.Text = inStock.ToString();
            lblLowStock.Text = lowStock.ToString();
            lblOutStock.Text = outStock.ToString();
        }

        // VALIDATION
        private bool ValidateProduct()
        {
            if (string.IsNullOrWhiteSpace(txtProductName.Text))
            {
                MessageBox.Show("Please enter the product name.");
                txtProductName.Focus();
                return false;
            }

            if (txtProductName.Text.Trim().Length > 100)
            {
                MessageBox.Show("Product name must not exceed 100 characters.");
                return false;
            }

            if (txtCategory.Text.Trim().Length > 50)
            {
                MessageBox.Show("Category must not exceed 50 characters.");
                return false;
            }

            return true;
        }

        // ADD PRODUCT
        private void AddProduct_Click(object? sender, EventArgs e)
        {
            if (!ValidateProduct())
                return;

            try
            {
                bool added = DatabaseHelper.AddProduct(
                    txtProductName.Text.Trim(),
                    txtCategory.Text.Trim(),
                    Decimal.ToInt32(numQuantity.Value),
                    Decimal.ToInt32(numReorderLevel.Value),
                    numPrice.Value,
                    txtDescription.Text.Trim());

                if (added)
                {
                    MessageBox.Show(
                        "Product added successfully.",
                        "HansLogin",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);

                    ClearFields();
                    LoadProducts();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Unable to add product.\n\n" + ex.Message,
                    "Product Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // GET SELECTED PRODUCT ID
        private int? GetSelectedProductId()
        {
            DataGridViewRow? row = dgvProducts.CurrentRow;

            if (row == null ||
                !dgvProducts.Columns.Contains("ProductID"))
                return null;

            DataGridViewCell? cell = row.Cells["ProductID"];

            if (cell.Value == null || cell.Value == DBNull.Value)
                return null;

            return Convert.ToInt32(cell.Value);
        }

        // UPDATE PRODUCT
        private void UpdateProduct_Click(object? sender, EventArgs e)
        {
            int? selectedId = GetSelectedProductId();

            if (selectedId == null)
            {
                MessageBox.Show("Please select a product to update.");
                return;
            }

            if (!ValidateProduct())
                return;

            try
            {
                bool updated = DatabaseHelper.UpdateProduct(
                    selectedId.Value,
                    txtProductName.Text.Trim(),
                    txtCategory.Text.Trim(),
                    Decimal.ToInt32(numQuantity.Value),
                    Decimal.ToInt32(numReorderLevel.Value),
                    numPrice.Value,
                    txtDescription.Text.Trim());

                if (updated)
                {
                    MessageBox.Show(
                        "Product updated successfully.",
                        "HansLogin",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);

                    ClearFields();
                    LoadProducts();
                }
                else
                {
                    MessageBox.Show("The selected product was not found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Unable to update product.\n\n" + ex.Message,
                    "Product Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // DELETE PRODUCT
        private void DeleteProduct_Click(object? sender, EventArgs e)
        {
            int? selectedId = GetSelectedProductId();

            if (selectedId == null)
            {
                MessageBox.Show("Please select a product to delete.");
                return;
            }

            DialogResult confirm = MessageBox.Show(
                "Are you sure you want to delete this product?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (confirm != DialogResult.Yes)
                return;

            try
            {
                bool deleted = DatabaseHelper.DeleteProduct(selectedId.Value);

                if (deleted)
                {
                    MessageBox.Show(
                        "Product deleted successfully.",
                        "HansLogin",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);

                    ClearFields();
                    LoadProducts();
                }
                else
                {
                    MessageBox.Show("The selected product was not found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Unable to delete product.\n\n" + ex.Message,
                    "Product Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // GET CELL VALUE SAFELY
        private object? GetCellValue(DataGridViewRow row, string columnName)
        {
            if (!dgvProducts.Columns.Contains(columnName))
                return null;

            DataGridViewCell? cell = row.Cells[columnName];
            return cell?.Value;
        }

        // SELECT PRODUCT
        private void DgvProducts_SelectionChanged(object? sender, EventArgs e)
        {
            DataGridViewRow? row = dgvProducts.CurrentRow;

            if (row == null)
                return;

            object? idValue = GetCellValue(row, "ProductID");

            if (idValue == null || idValue == DBNull.Value)
                return;

            lblSelectedId.Text =
                "Selected Product ID: " + Convert.ToString(idValue);

            txtProductName.Text =
                Convert.ToString(GetCellValue(row, "ProductName")) ?? "";

            txtCategory.Text =
                Convert.ToString(GetCellValue(row, "Category")) ?? "";

            object? quantityValue = GetCellValue(row, "Quantity");
            object? priceValue = GetCellValue(row, "Price");
            object? reorderValue = GetCellValue(row, "ReorderLevel");

            decimal quantity =
                quantityValue == null || quantityValue == DBNull.Value
                    ? 0 : Convert.ToDecimal(quantityValue);

            decimal price =
                priceValue == null || priceValue == DBNull.Value
                    ? 0 : Convert.ToDecimal(priceValue);

            decimal reorderLevel =
                reorderValue == null || reorderValue == DBNull.Value
                    ? 5 : Convert.ToDecimal(reorderValue);

            numQuantity.Value = Math.Min(
                numQuantity.Maximum,
                Math.Max(numQuantity.Minimum, quantity));

            numPrice.Value = Math.Min(
                numPrice.Maximum,
                Math.Max(numPrice.Minimum, price));

            numReorderLevel.Value = Math.Min(
                numReorderLevel.Maximum,
                Math.Max(numReorderLevel.Minimum, reorderLevel));

            txtDescription.Text =
                Convert.ToString(GetCellValue(row, "Description")) ?? "";
        }

        // CLEAR FIELDS
        private void ClearFields()
        {
            txtProductName.Clear();
            txtCategory.Clear();
            txtDescription.Clear();

            numQuantity.Value = 0;
            numPrice.Value = 0;
            numReorderLevel.Value = 5;

            lblSelectedId.Text = "Selected Product ID: New";

            dgvProducts.ClearSelection();
            dgvProducts.CurrentCell = null;
        }
    }
}
